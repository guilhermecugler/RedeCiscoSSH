<!doctype html>
<html lang="pt-br">
	<head>
		<title>Bem Vindoª a REDE CISCO</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		
       <!-- Bootstrap Css -->
        <link href="./css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />

        <!-- Icons Css -->
        <link href="./css/icons.min.css" rel="stylesheet" type="text/css" />

        <!-- App Css-->
        <link href="./css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Noty CSS -->
        <link rel="stylesheet" href="../../cdn.jsdelivr.net/gh/needim/noty%4077268c46/lib/noty.html">
        <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.html">
		
		<!-- BEGIN: Theme CSS -->
		<link rel="stylesheet" type="text/css" href="../../../app-assets/css/themes/background-store.css">

        <!-- SCRIPT -->
        <script>button.onclick = verifica;</script> 
		
	</head>
	<body class="is-preload">

		<!-- Header -->
			<div id="header">
				<span class="image"><img src="images/logo.png" alt=""></span>
				<h1>REDE CISCO - TE CONECTANDO À + DE 4 ANOS</h1>
				<p>Somos uma comunidade focada em trazer o melhor que esse mundão da internet tem a proporcionar a todos.</a>
				<br />
				Essa é uma breve apresentação sobre a REDE CISCO, espero que venha nos conhecer melhor, faça um <a href="https://tawk.to/chat/63bf65af47425128790cf833/1gmhqae6b">TESTE GRÁTIS!</a>.</p>
			</div>

		<!-- Main -->
			<div id="main">

				<header class="major container medium">
					<h2>REDE CISCO
					<br />
					Internet Móvel Ilimitada
					<br />
					Canais via Internet</h2>
				</header>

				<div class="box alt container">
					<section class="feature left">
						<a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a>
						<div class="content">
							<h3>𝗔 𝗥𝗘𝗗𝗘 𝗖𝗜𝗦𝗖𝗢</h3>
							<p>ᴀ ʀᴇᴅᴇ ᴄɪsᴄᴏ ɴᴀsᴄᴇᴜ ᴀᴛʀᴀᴠés ᴅᴀ ɪᴅéɪᴀ ᴅᴇ ᴛʀᴀᴢᴇʀ sᴇʀᴠɪçᴏs ᴏɴʟɪɴᴇ, ᴜɴɪɴᴅᴏ ǫᴜᴀʟɪᴅᴀᴅᴇ ᴇ ᴜᴍ ᴍᴇʟʜᴏʀ sᴜᴘᴏʀᴛᴇ ᴀᴏ ᴄʟɪᴇɴᴛᴇ. ᴠᴇɴʜᴀ ɴᴏs ᴄᴏɴʜᴇᴄᴇʀ!</p>
						</div>
					</section>
					<section class="feature right">
						<a href="#" class="image"><img src="images/pic02.jpg" alt="" /></a>
						<div class="content">
							<h3>𝗜𝗡𝗧𝗘𝗥𝗡𝗘𝗧 𝗠𝗢𝗩𝗘𝗟 𝗜𝗟𝗜𝗠𝗜𝗧𝗔𝗗𝗔</h3>
							<p>ᴀ ɪɴᴛᴇʀɴᴇᴛ ɪʟɪᴍɪᴛᴀᴅᴀ ᴠɪᴀ ᴀᴘʟɪᴄᴀᴛɪᴠᴏ, sᴇʀᴠᴇ ᴘᴀʀᴀ ᴠᴏᴄê ǫᴜᴇ ᴘᴏssᴜɪ ᴜᴍ ᴄʜɪᴘ ᴘʀé ᴘᴀɢᴏ ᴀᴛɪᴠᴏ (sᴇᴍ ɪɴᴛᴇʀɴᴇᴛ ᴅᴇ ᴘʀᴇғᴇʀêɴᴄɪᴀ) ᴘᴏssᴀ ᴜᴛɪʟɪᴢᴀʀ ᴜᴍᴀ ᴄᴏɴᴇxãᴏ ɪʟɪᴍɪᴛᴀᴅᴀ sᴇᴍ sᴇ ᴘʀᴇᴏᴄᴜᴘᴀʀ ᴄᴏᴍ ʀᴇᴅᴜçãᴏ ᴅᴇ ᴅᴀᴅᴏs! é ɪʟɪᴍɪᴛᴀᴅᴏ ᴍᴇsᴍᴏ!</p>
						</div>
					</section>
					<section class="feature left">
						<a href="#" class="image"><img src="images/pic03.jpg" alt="" /></a>
						<div class="content">
							<h3>𝗔𝗥𝗘𝗔 𝗗𝗢 𝗖𝗟𝗜𝗘𝗡𝗧𝗘</h3>
							<p>ᴄᴏɴᴛᴀᴍᴏs ᴄᴏᴍ ᴜᴍᴀ áʀᴇᴀ ᴅᴏ ᴄʟɪᴇɴᴛᴇ ᴄᴏᴍᴘʟᴇᴛᴀ, ᴄᴏᴍ ғᴜɴᴄɪᴏɴᴀʟɪᴅᴀᴅᴇs ᴇ ɪɴғᴏʀᴍᴀçõᴇs sᴏʙʀᴇ ᴏ ᴘʟᴀɴᴏ ᴄᴏɴᴛʀᴀᴛᴀᴅᴏ, ᴇ ᴛᴀᴍʙéᴍ, ᴏ ɴᴏssᴏ sᴜᴘᴏʀᴛᴇ ᴏɴʟɪɴᴇ ᴅɪʀᴇᴛᴀᴍᴇɴᴛᴇ ᴘᴇʟᴏ ᴘᴀɪɴᴇʟ, sᴜᴘᴏʀᴛᴇ 24ʜʀs!</p>
						</div>
					</section>
				</div>
        <!-- Begin page -->

            <div class="main-content mt-5">
                <div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
              
                        <div class="row">
                            <div class="col-md-3 col-xl-10">
                                <div class="card">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col-xl-3 border-right">
                                            <div class="text-center p-sm-4 pt-4 mt-2">
                                                <div class="avatar-md mx-auto border border-soft-primary p-1 rounded-circle mb-2" style="height: 6rem;width: 6rem;">

                                                    <span class="avatar-title rounded-circle bg-soft-primary text-primary h3">

                                                        <img class="rounded-circle" width="90" height="90" src="img/internet01.png">

                                                    </span>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <div class="p-4 text-center text-xl-left">
                                                <h4 class="text-truncate font-size-22 mb-0"></h4>
                                                <div class="text-muted mt-3 pt-3 border-top">
                                                    <div class="row" style="text-align: center;">
                                                        <div class="col-sm-4">
                                                            <div class="mb-sm-0 mb-3">
                                                                <p class="text-muted mb-2 text-truncate">
                                                                    <i class="uil uil-import mr-1"></i> Rede Cisco 5G+
                                                                </p>
                                                                <h5 class="mb-0">
                                                                    SERVIDOR<br>TURBO-01<br>
                                                                </h5><br>
                                                            </div>
                                                        </div>
														
														<div class="col-sm-4">
                                                            <div class="mb-sm-0 mb-3">
                                                                <p class="text-muted mb-2 text-truncate">
                                                                    <i class="uil uil-import mr-1"></i> Aplicativo Funcional!
                                                                </p>
                                                                <h5 class="mb-0">
                                                                    OPERADORAS<br>VIVO|TIM<br>CLARO|OI
                                                                </h5><br>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-4">
                                                            <div>
                                                                <p class="text-muted mb-2 text-truncate" >
                                                                    <i class="uil uil-history mr-1"></i>Ultima Atualização 
                                                                </p>
                                                                <h5 class="mb-0">
																	17/01 v1.2</h5>
                                                            </div>
                                                        </div>
														
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 border-left">
                                            <div class="text-center p-sm-4 pt-4">
                                                <div class="mx-auto p-1 mb-2">
                                                    <a onclick="initDownload('href')" type="button" class="btn btn-primary btn-lg waves-effect waves-light" href="./apk/Rede Cisco 5G+(1.0).apk"><i class="uil-google-play mr-2"></i>BAIXAR APP</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 col-xl-10">
                                <div class="card">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col-xl-3 border-right">
                                            <div class="text-center p-sm-4 pt-4 mt-2">
                                                <div class="avatar-md mx-auto border border-soft-primary p-1 rounded-circle mb-2" style="height: 6rem;width: 6rem;">

                                                    <span class="avatar-title rounded-circle bg-soft-primary text-primary h3">

                                                        <img class="rounded-circle" width="90" height="90" src="img/p2cine.png">

                                                    </span>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <div class="p-4 text-center text-xl-left">
                                                <h4 class="text-truncate font-size-22 mb-0"></h4>
                                                <div class="text-muted mt-3 pt-3 border-top">
                                                    <div class="row" style="text-align: center;">
                                                        <div class="col-sm-4">
                                                            <div class="mb-sm-0 mb-3">
                                                                <p class="text-muted mb-2 text-truncate">
                                                                    <i class="uil uil-import mr-1"></i> RedeCiscoTV-(P2Cine)
                                                                </p>
                                                                <h5 class="mb-0">
                                                                    +1000 canais<br>+9999 Filmes e Séries<br>
                                                                </h5><br>
                                                            </div>
                                                        </div>
														
														<div class="col-sm-4">
                                                            <div class="mb-sm-0 mb-3">
                                                                <p class="text-muted mb-2 text-truncate">
                                                                    <i class="uil uil-import mr-1"></i> SISTEMA COMPATIVEL
                                                                </p>
                                                                <h5 class="mb-0">
                                                                    Smart TV e TV Box<br>Android ou IOS<br>Computador e Notebook
                                                                </h5><br>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-4">
                                                            <div>
                                                                <p class="text-muted mb-2 text-truncate">
                                                                    <i class="uil uil-history mr-1"></i>Ultima Atualização
                                                                </p>
                                                                <h5 class="mb-0">10/01
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 border-left">
                                            <div class="text-center p-sm-4 pt-4">
                                                <div class="mx-auto p-1 mb-2">
                                                    <a onclick="initDownload('href')" type="button" class="btn btn-primary btn-lg waves-effect waves-light" href="./apk/RedeCiscoTV-(P2Cine).apk"><i class="uil-google-play mr-2"></i>BAIXAR APP</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-1 col-xl-10">
                                <div class="row">
                                    <div class="col-sm-12 mt-5">
                                        <div class="card text-center mt-3 mb-3" style="border-radius: 3.25rem;">
                                            <h2 class="mt-5 mb-1">
                                                <div class="text-dark">REDE CISCO</div>
                                            </h2>
                                            <p class="font-size-16 text-muted mt-3">
                                                Nossos serviços são de alta qualidade, apps modernos e atualizados para você nunca ficar offline.
                                            </p>
                                            <div class="row mt-4 mb-5">
                                                <div class="col-12">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- container-fluid -->
            </div>		
            <!-- End Page-content -->
		
				<footer class="major container medium">
					<h3>VENHA CONHECER A REDE CISCO!</h3>
					<p>Temos uma equipe qualificada para lhe atender desde o TESTE GRÁTIS ao PÓS VENDA, nossa proposta é que o cliente posso utilizar e usufruir da melhor forma os serviços prestados pela REDE CISCO!</p>
					<ul class="actions special">
						<li><a href="http://central.redecisco.online" class="button">ENTRAR NA REDE CISCO</a></li>
					</ul>
				</footer>
		
            <!-- RODAPE -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2021 - <script> document.write(new Date().getFullYear())</script> EMPRESA 🚀© <b><a href="termos.php" target="black"></i>Termos de uso</b></a>
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Desenvolvido por <a href="https://kiwify.app/NKl55g5" target="_blank" class="text-reset font-weight-bold">EMPRESA</a>

                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- FIM RODAPE -->
        </div>

        <!-- JAVASCRIPT -->
        <script type="text/javascript">

            function initDownload() 

                location.href = lnk;
                button.onclick = verifica;

                new Noty({

                    type: 'success',
                    layout: 'bottomCenter',
                    theme: 'metroui',
                    timeout: 3000,
                    animation: {
                        open: 'animated fadeInUp',
                        close: 'animated fadeOutDown'
                    },

                    text: 'Iniciando o download do aplicativo...'

                }).show();
        </script>
        <!-- FIM JAVASCRIPT -->
		
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/63bf65af47425128790cf833/1gmhqae6b';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
		
    </body>

</html>





