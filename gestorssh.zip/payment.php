<?php
ini_set('display_errors', 1);

session_start();

$access_token = $_SESSION['CLIENT_SECRET'];
$id_ssh = $_SESSION['id_usuario_ssh'];



if (isset($_POST)) {

  if (isset($_POST['pix'])) {

    if ($_POST['pix']) {

      $valor = doubleval($_SESSION['valor_venda']);

      require_once __DIR__ . '/vendor/autoload.php';
      MercadoPago\SDK::setAccessToken($access_token);


      $payment = new MercadoPago\Payment();
      $payment->description = $id_ssh;
      $payment->transaction_amount = (double) $valor;
      $payment->payment_method_id = "pix";

      $payment->notification_url = 'https://central.cwplay.online/notification.php?vendedor='.$_SESSION['id_vendedor'];
      $payment->external_reference = $id_ssh;

      $payment->payer = array(
        "email" => 'emailcliente@gmail.com',
        "first_name" => 'Primeiro nome do cliente',
        "address" => array(
          "zip_code" => "06233200",
          "street_name" => "Av. das Nações Unidas",
          "street_number" => "3003",
          "neighborhood" => "Bonfim",
          "city" => "Osasco",
          "federal_unit" => "SP",
        )
      );

      $payment->save();


      echo json_encode($payment->point_of_interaction);

    } else {
      echo json_encode(
        array(
          'status' => 'error',
          'message' => 'pix required'
        )
      );
      exit;
    }

  } else {
    echo json_encode(
      array(
        'status' => 'error',
        'message' => 'pix required'
      )
    );
    exit;
  }

} else {
  echo json_encode(
    array(
      'status' => 'error',
      'message' => 'post required'
    )
  );
  exit;
}