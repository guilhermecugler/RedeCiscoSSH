<?php
$procnoticias = "select * FROM noticias where status='ativo'";
$procnoticias = $conn->prepare($procnoticias);
$procnoticias->execute();

?>

<!-- Noticias -->
<?php if ($procnoticias->rowCount() > 0) {
  $noticia = $procnoticias->fetch();

  $datapega = $noticia['data'];
  $data = date('D', strtotime($datapega));
  $mes = date('M', strtotime($datapega));
  $dia = date('d', strtotime($datapega));
  $ano = date('Y', strtotime($datapega));

  $semana = array(
    'Sun' => 'Domingo',
    'Mon' => 'Segunda-Feira',
    'Tue' => 'Terça-Feira',
    'Wed' => 'Quarta-Feira',
    'Thu' => 'Quinta-Feira',
    'Fri' => 'Sexta-Feira',
    'Sat' => 'Sábado'
  );

  $mes_extenso = array(
    'Jan' => 'Janeiro',
    'Feb' => 'Fevereiro',
    'Mar' => 'Marco',
    'Apr' => 'Abril',
    'May' => 'Maio',
    'Jun' => 'Junho',
    'Jul' => 'Julho',
    'Aug' => 'Agosto',
    'Sep' => 'Setembro',
    'Oct' => 'Outubro',
    'Nov' => 'Novembro',
    'Dec' => 'Dezembro'
  );


?>
  <?php
  $SQLSubSSH = "SELECT * FROM usuario_ssh where id_usuario_ssh='" . $usuario['id_usuario_ssh'] . "' ORDER BY id_usuario_ssh desc";
  $SQLSubSSH = $conn->prepare($SQLSubSSH);
  $SQLSubSSH->execute();
  if (($SQLSubSSH->rowCount()) > 0) {
    while ($row = $SQLSubSSH->fetch()) {



      $SQLUsuarioSSH = "SELECT * from usuario_ssh WHERE id_servidor = '" . $servidor['id_servidor'] . "' and id_usuario='" . $row['id_usuario'] . "'";
      $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
      $SQLUsuarioSSH->execute();
      $contas = $SQLUsuarioSSH->rowCount();
      if ($contas == 0) {
        $contas = 0;
      }

      //Calcula os dias restante
      $data_atual = date("Y-m-d");
      $data_validade = $row['data_validade'];
      if ($data_validade > $data_atual) {
        $data1 = new DateTime($data_validade);
        $data2 = new DateTime($data_atual);
        $dias_acesso = 0;
        $diferenca = $data1->diff($data2);
        $ano = $diferenca->y * 364;
        $mes = $diferenca->m * 30;
        $dia = $diferenca->d;
        $dias_acesso = $ano + $mes + $dia;
      } else {
        $dias_acesso = 0;
      }

      $SQLopen = "select * from ovpn WHERE servidor_id = '" . $row['id_servidor'] . "' ";
      $SQLopen = $conn->prepare($SQLopen);
      $SQLopen->execute();
      if ($SQLopen->rowCount() > 0) {
        $openvpn = $SQLopen->fetch();
        $texto = "<a href='../admin/pages/servidor/baixar_ovpn.php?id=" . $openvpn['id'] . "' class=\"label label-info\">Baixar</a>";
      } else {
        $texto = "<span class=\"label label-danger\">Indisponivel</span>";
      }


  ?>

  <?php
    }
  }


  ?>

  <div class="demo-spacing-0 text-center mb-2">
    <div class="alert alert-primary alert-dismissible" role="alert">
      <h2 class="alert-heading text-warning"><i data-feather='alert-octagon'></i> <?php echo $noticia['titulo']; ?></h2>
      <div class="alert-body text-warning">
        <?php echo $noticia['subtitulo']; ?> <br />
        <?php echo $noticia['msg']; ?><br />
        <?php echo $semana["$data"] . ", {$dia} de " . $mes_extenso["$mes"] . " de {$ano}";; ?>
      </div>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  </div>


<?php } ?>

<section id="dashboard-analytics">
  <style>
    .img-fluid {
      max-width: 100%;
      height: 100px;
      background: linear-gradient(118deg, #138d9a, rgb(16 134 218));
    }
  </style>
  <div class="col-12">
    <div class="card card-profile border-primary">
      <img src="" class="img-fluid ">
      <div class="card-body">
        <div class="profile-image-wrapper">
          <div class="profile-image">
            <div class="avatar-content">
              <img src="../../../app-assets/images/avatars/<?php echo $avatarusu; ?>" alt="user">
            </div>
          </div>
        </div>
        <h3>BEM VINDO(A) <?php echo strtoupper($usuario['login']); ?></h3>
        <a class="dropdown-item"><i class="me-50" data-feather="calendar"></i>Resta: <span class="badge badge-light-info rounded-pill ms-auto me-1"><?php echo $dias_acesso . " dias"; ?></span></a>
        <span class="badge badge-light-primary profile-badge">
        </span>
      </div>
    </div>
  </div>
</section>
<!-- Dashboard Analytics end -->
<section id="statistics-card">
  <div class="row">
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card border-primary">
        <a href="#">
          <div class="card-header d-flex flex-column align-items-center pb-0">
            <div class="avatar bg-light-success avatar-xl">
              <div class="avatar-content">
                <i data-feather='calendar'></i>
              </div>
            </div>
            <h4 class="text-bold-700 mt-1">Restam <?php echo $dias_acesso; ?> dias</h4>
            <p class="mb-2"></p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card border-primary">
        <a href="javascript:modalPix()">
          <div class="card-header d-flex flex-column align-items-center pb-0">
            <div class="avatar bg-light-success avatar-xl">
              <div class="avatar-content">
                <i data-feather='shopping-cart'></i>
              </div>
            </div>
            <h4 class="text-bold-700 mt-1 mb-25"><?php  ?> Renovar Plano</h4>
            <p class="mb-2"></p>
          </div>
        </a>
      </div>
    </div>


    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card border-primary">
        <a href="https://central.redecisco.online/site">
          <div class="card-header d-flex flex-column align-items-center pb-0">
            <div class="avatar bg-light-primary avatar-xl">
              <div class="avatar-content">
                <i data-feather='download'></i>
              </div>
            </div>
            <h4 class="text-bold-700 mt-1"><? php ?> Loja de Apps</h4>
            <p class="mb-2"></p>
          </div>
        </a>
      </div>
    </div>

    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card border-primary">
        <a href="https://central.redecisco.online/site">
          <div class="card-header d-flex flex-column align-items-center pb-0">
            <div class="avatar bg-light-danger avatar-xl">
              <div class="avatar-content">
                <i data-feather='info'></i>
              </div>
            </div>
            <h4 class="text-bold-700 mt-1"><?php ?> Como Utilizar</h4>
            <p class="mb-2"></p>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>