<?php
ini_set('display_errors', 1);
require_once("pages/system/segurancacliente.php");
require_once('pages/system/classe.ssh.php');
  session_start();

  function dateDiffInDays($date1, $date2) 
  {
      // Calculating the difference in timestamps
      $diff = strtotime($date2) - strtotime($date1);
  
      // 1 day = 24 hours
      // 24 * 60 * 60 = 86400 seconds
      return abs(round($diff / 86400));
  }

if(!isset($_GET['tipo'])){

  $SQLMPNotification = "SELECT * FROM usuario WHERE id_usuario = '" .$_GET['vendedor'] . "'";
  $SQLMPNotification = $conn->prepare($SQLMPNotification);
  $SQLMPNotification->execute();
  $chaveMPNotification = $SQLMPNotification->fetch();
  $access_token = $chaveMPNotification['tokensecret_mp'];
  require_once __DIR__ . '/vendor/autoload.php';
  MercadoPago\SDK::setAccessToken($access_token);
  
  $payment = MercadoPago\Payment::find_by_id($_GET["id"]);
    
  $fp=fopen('log.txt','a');
    /*
    Aqui achamos o paramentro data_id
    Quando for enviar o pagamento precisamos enviar a reference externa assim: $payment->external_reference = '123ABC'
    $html='';
    foreach ($_GET as $key => $value){
        $html.=$key.'=>'.$value.' | ';
    }*/
  $html='ID do pagamento: '.$payment->{'id'}.' | Status: '.$payment->{'status'}.' | ID Vendedor: '.$_GET['vendedor'].' | Login cliente: '.$payment->{'description'}."\r\n";
  $write=fwrite($fp,$html);
  fclose($fp);
  
  $status_pagamento = $payment->{'status'};
  $id_cliente = $payment->{'description'};
  $id_pagamento = $payment->{'id'};
  
  $SQLVerificaPagamento = "SELECT * FROM pagamentos_aprovados WHERE payment_id =".$id_pagamento;
  $SQLVerificaPagamento = $conn->prepare($SQLVerificaPagamento);
  $SQLVerificaPagamento->execute();
  $linha = $SQLVerificaPagamento->rowCount();
  
  
  if ($status_pagamento == "approved" and $linha < 1){
    echo "Aprovado";
  
    $SQLAtualizaPagamentos = "INSERT INTO pagamentos_aprovados(payment_id, usuario_login, data_aprovado) VALUES (".$id_pagamento."," .$id_cliente.", now())";
    $SQLAtualizaPagamentos = $conn->prepare($SQLAtualizaPagamentos);
    $SQLAtualizaPagamentos->execute();
    
    $SQLAtualizaCliente = "UPDATE usuario_ssh SET data_validade= DATE_ADD(data_validade, INTERVAL 30 DAY) WHERE id_usuario_ssh = ".$payment->{'description'};
    $SQLAtualizaCliente = $conn->prepare($SQLAtualizaCliente);
    $SQLAtualizaCliente->execute();

 ######### A PARTIR DAQUI ATUALIZA O USUARIO SSH DIRETO NO SERVIDOR #############
 $id_usuarioSSH = $id_cliente;
 //Carrega usuarioSSH
 $SQLUsuarioSSH = "select * from usuario_ssh WHERE id_usuario_ssh = '".$id_usuarioSSH."'";
 $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
 $SQLUsuarioSSH->execute();
 $usuario_ssh = $SQLUsuarioSSH->fetch();

 //Carrega servidor
 $id_servidor =  $usuario_ssh['id_servidor'];
 $SQLServidor = "select * from servidor WHERE id_servidor = '".$usuario_ssh['id_servidor']."'";
 $SQLServidor = $conn->prepare($SQLServidor);
 $SQLServidor->execute();
 $servidor = $SQLServidor->fetch();


 $dias_acesso_validade = date("Y-m-d", strtotime($usuario_ssh['data_validade']));
 $hoje = date("Y-m-d");

 echo 'Vence dia: '.$dias_acesso_validade."\r\n";
 echo 'Hoje é dia: '.$hoje."\r\n";

 $dias_acesso = dateDiffInDays($dias_acesso_validade, $hoje);
 echo 'Adiciona mais: '.$dias_acesso.' dias';

 //Realiza a comunicacao com o servidor
 $ip_servidor= $servidor['ip_servidor'];
 $loginSSH= $servidor['login_server'];
 $senhaSSH=  $servidor['senha'];
 $ssh = new SSH2($ip_servidor);
 $ssh->auth($loginSSH,$senhaSSH);

 $ssh->exec('[[ -f "/opt/sshplus/sshplus" ]] && /opt/sshplus/plugin-sync --date_user '.$usuario_ssh['login'].' '.$dias_acesso.' || ./AlterarData.sh '.$usuario_ssh['login'].' '.$dias_acesso.'');
 $mensagem = (string) $ssh->output();

 
 $fp=fopen('log.txt','a');
 $html='Usuário '.$payment->{'description'}.' renovado, vence em '.$dias_acesso." dias\r\n";
 $write=fwrite($fp,$html);
 fclose($fp);

 ######################  FIM ATUALIZA DIAS USUARIO SSH    ########################################  
  }else{
    echo 'Usuário já renovado';
  };

}else{
  echo 'revendedor';
  
  $SQLMPNotification = "SELECT * FROM admin WHERE id_administrador = '" .$_GET['vendedor'] . "'";
  $SQLMPNotification = $conn->prepare($SQLMPNotification);
  $SQLMPNotification->execute();
  $chaveMPNotification = $SQLMPNotification->fetch();
  $access_token = $chaveMPNotification['tokensecret_mp'];
  require_once __DIR__ . '/vendor/autoload.php';
  MercadoPago\SDK::setAccessToken($access_token);
  
  $payment = MercadoPago\Payment::find_by_id($_GET["id"]);
    
  $fp=fopen('log.txt','a');
    /*
    Aqui achamos o paramentro data_id
    Quando for enviar o pagamento precisamos enviar a reference externa assim: $payment->external_reference = '123ABC'
    $html='';
    foreach ($_GET as $key => $value){
        $html.=$key.'=>'.$value.' | ';
    }*/
  $html='ID do pagamento: '.$payment->{'id'}.' | Status: '.$payment->{'status'}.' | ID Vendedor: '.$_GET['vendedor'].' | Login cliente: '.$payment->{'description'}."\r\n";
  $write=fwrite($fp,$html);
  fclose($fp);
  
  $status_pagamento = $payment->{'status'};
  $id_cliente = $payment->{'description'};
  $id_pagamento = $payment->{'id'};
  
  $SQLVerificaPagamento = "SELECT * FROM pagamentos_aprovados WHERE payment_id =".$id_pagamento;
  $SQLVerificaPagamento = $conn->prepare($SQLVerificaPagamento);
  $SQLVerificaPagamento->execute();
  $linha = $SQLVerificaPagamento->rowCount();
  
  
  if ($status_pagamento == "approved" and $linha < 1){
    echo $linha;
  
    $SQLAtualizaPagamentos = "INSERT INTO pagamentos_aprovados(payment_id, usuario_login, data_aprovado) VALUES (".$id_pagamento."," .$id_cliente.", now())";
    $SQLAtualizaPagamentos = $conn->prepare($SQLAtualizaPagamentos);
    $SQLAtualizaPagamentos->execute();
    
    $SQLAtualizaCliente = "UPDATE acesso_servidor SET validade= DATE_ADD(validade, INTERVAL 30 DAY) WHERE id_usuario = ".$payment->{'description'};
    $SQLAtualizaCliente = $conn->prepare($SQLAtualizaCliente);
    $SQLAtualizaCliente->execute();
  
  }else{
    echo 'Usuário já renovado';
  };
}