<?php
ini_set('display_errors', 1);

require_once("pages/system/segurancacliente.php");
require_once("pages/system/config.php");
require_once("pages/system/classe.ssh.php");

protegePagina("user");

session_start();

$SQLUsuario = "SELECT * FROM usuario_ssh WHERE id_usuario_ssh = '" . $_SESSION['usuarioID'] . "'";
$SQLUsuario = $conn->prepare($SQLUsuario);
$SQLUsuario->execute();
$usuario = $SQLUsuario->fetch();
$_SESSION['id_usuario_ssh'] = $usuario['id_usuario_ssh'];
$_SESSION['id_vendedor'] = $usuario['id_usuario'];
$_SESSION['usuario_login'] = $usuario['login'];


$SQLMP = "SELECT * FROM usuario WHERE id_usuario = '" . $usuario['id_usuario'] . "'";
$SQLMP = $conn->prepare($SQLMP);
$SQLMP->execute();
$dadosMP = $SQLMP->fetch();
$_SESSION['CLIENT_SECRET'] = $dadosMP['tokensecret_mp'];


$SQLDadosMP = "SELECT * FROM usuario WHERE id_usuario = '" . $usuario['id_usuario'] . "'";
$SQLDadosMP = $conn->prepare($SQLDadosMP);
$SQLDadosMP->execute();
$dadosMP2 = $SQLDadosMP->fetch();
$_SESSION['valor_venda'] = $dadosMP2['valor_venda'];

// avatares
switch ($usuario['avatar']) {
    case 1:
        $avatarusu = "avatar1.png";
        break;
    case 2:
        $avatarusu = "avatar2.png";
        break;
    case 3:
        $avatarusu = "avatar3.png";
        break;
    case 4:
        $avatarusu = "avatar4.png";
        break;
    case 5:
        $avatarusu = "avatar5.png";
        break;
    default:
        $avatarusu = "boxed-bg.png";
        break;
}



$tipouser = 'Usuário VPN';


$datacad = $usuario['data_validade'];

$partes = explode("-", $datacad);
$ano = $partes[0];
$mes = $partes[1];

$Mes = muda_mes($mes);
$Meses = muda_mes2($mes);


//Arquivos download
$SQLArquivos = "select * from  arquivo_download";
$SQLArquivos = $conn->prepare($SQLArquivos);
$SQLArquivos->execute();
$todosarquivos = $SQLArquivos->rowCount();



?>
<?php
$SQLSubSSH = "SELECT * FROM usuario_ssh where id_usuario_ssh='" . $usuario['id_usuario_ssh'] . "' ORDER BY id_usuario desc";
$SQLSubSSH = $conn->prepare($SQLSubSSH);
$SQLSubSSH->execute();
if (($SQLSubSSH->rowCount()) > 0) {
    while ($row = $SQLSubSSH->fetch()) {





        $SQLUsuarioSSH = "SELECT * from usuario_ssh WHERE id_servidor = '" . $servidor['id_servidor'] . "' and id_usuario='" . $row['id_usuario'] . "'";
        $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
        $SQLUsuarioSSH->execute();
        $contas = $SQLUsuarioSSH->rowCount();
        if ($contas == 0) {
            $contas = 0;
        }

        //Calcula os dias restante
        $data_atual = date("Y-m-d");
        $data_validade = $row['data_validade'];
        if ($data_validade > $data_atual) {
            $data1 = new DateTime($data_validade);
            $data2 = new DateTime($data_atual);
            $dias_acesso = 0;
            $diferenca = $data1->diff($data2);
            $ano = $diferenca->y * 364;
            $mes = $diferenca->m * 30;
            $dia = $diferenca->d;
            $dias_acesso = $ano + $mes + $dia;

        } else {
            $dias_acesso = 0;
        }

        $SQLopen = "select * from ovpn WHERE servidor_id = '" . $row['id_servidor'] . "' ";
        $SQLopen = $conn->prepare($SQLopen);
        $SQLopen->execute();
        if ($SQLopen->rowCount() > 0) {
            $openvpn = $SQLopen->fetch();
            $texto = "<a href='../admin/pages/servidor/baixar_ovpn.php?id=" . $openvpn['id'] . "' class=\"label label-info\">Baixar</a>";
        } else {
            $texto = "<span class=\"label label-danger\">Indisponivel</span>";
        }


        ?>

    <?php
    }

}


?>
<!DOCTYPE html>
<html class="loading bordered-layout" lang="pt" data-layout="bordered-layout" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Gerenciador de conexôes SSH">
    <meta name="keywords" content="VPN GEMPRESA 🚀, VPN, SSH, Gratis, Registrar">
    <meta name="author" content="Crazy">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="theme-color" content="#FFFFFF">
    <title>EMPRESA 🚀 - PAINEL</title>
    <link rel="apple-touch-icon" href="../app-assets/images/ico/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="../app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600"
        rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/charts/apexcharts.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/extensions/toastr.min.css">
    <link rel="stylesheet" type="text/css"
        href="../app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css"
        href="../app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css">


    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css"
        href="../app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css"
        href="../app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css"
        href="../app-assets/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/pickers/flatpickr/flatpickr.min.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/forms/select/select2.min.css">
    <!-- END: Vendor CSS-->
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/themes/bordered-layout.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/themes/semi-dark-layout.css">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/plugins/charts/chart-apex.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/plugins/extensions/ext-component-toastr.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/pages/app-invoice-list.css">


    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <!-- END: Custom CSS-->
    <!--<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static  " data-open="click"
    data-menu="vertical-menu-modern" data-col="">
    <!-- Modal -->
    <div class="modal fade" id="modalPix" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Pagamento com pix</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img id="load" src="https://i.gifer.com/VAyR.gif" alt="">

                    <div class="row" id="dix-pix" style="display:none;">
                        <div class="col-md-12">
                            <img src="" id="img-pix" width="100%" alt="">
                        </div>
                        <div class="col-md-12">
                            <textarea name="code-pix" class="form-control" id="code-pix" rows="8" cols="80"></textarea>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" onclick="javascript:copyToClipboard('#code-pix')" id="copiarButton" class="btn btn-secondary">Copiar</button>   
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">

$(document).ready(function () {
            $("#copiarButton").click(function (){
                var copyText = document.getElementById("code-pix");
                copyText.select();
                copyText.setSelectionRange(0, 99999)
                document.execCommand("copy");
            });
 });


        function fecharModal() {
            $("#modalPix").modal('hide');
        };

        function modalPix() {
            $("#modalPix").modal('show');

            $.post('payment.php', { pix: true }, function (response) {

                var obj = JSON.parse(response);
                console.log(response)


                var base64 = obj.transaction_data.qr_code_base64;
                var codePix = obj.transaction_data.qr_code;

                $("#load").hide();

                $("#img-pix").attr('src', 'data:image/jpeg;base64,' + base64);
                $("#code-pix").val(codePix);

                $("#dix-pix").show();


            })};
    </script>
    <div class="wrapper">

    </div>

    <script>
        //paste this code under head tag or in a seperate js file.
        // Wait for window load
        $(window).load(function () {
            // Animate loader off screen
            $(".se-pre-con").fadeOut('slow');;
        });
    </script>
<nav class="header-navbar navbar navbar-expand-lg align-items-center floating-nav navbar-light navbar-shadow container-xxl">
        <div class="navbar-container d-flex content">
            <div class="bookmark-wrapper d-flex align-items-center">
                <ul class="nav navbar-nav d-xl-none">
                    <li class="nav-item"><a class="nav-link menu-toggle" href="#"><i class="ficon" data-feather="menu"></i></a></li>
                </ul>
            </div>
            <ul class="nav navbar-nav align-items-center ms-auto">
                <li class="nav-item"><a class="nav-link nav-link-style"><i class="ficon" data-feather="moon"></i></a>
                </li>


               
            
                <li class="nav-item dropdown dropdown-user"><a class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="user-nav d-sm-flex d-none"><span class="user-name fw-bolder text-primary"><?php echo strtoupper($usuario['login']); ?></span><span class="user-status">Cliente</span></div><span class="avatar"><img class="round" src="../app-assets/images/avatars/<?php echo $avatarusu; ?>" alt="avatar" height="40" width="40"><span class="avatar-status-online"></span></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdown-user">
						<a class="dropdown-item" href="?page=servidor/listar"><i class="me-50" data-feather="calendar"></i>Resta: <span class="badge badge-light-info rounded-pill ms-auto me-1"><?php echo $dias_acesso." dias"; ?></span></a>
                        <a class="dropdown-item" href="homecliente.php?page=admin/dados"><i class="me-50" data-feather="user"></i>Meus Dados</a>
                        <a class="dropdown-item" href="sair.php"><i class="me-50" data-feather="power"></i>Sair</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>




    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="false">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item me-auto"><a class="navbar-brand" href="homecliente.php"><span class="brand-logo">
                            <img class="round" src="../app-assets/images/logo/logo.png" alt="avatar" height="35"
                                width="28" />
                        </span>
                        <h2 class="brand-text">EMPRESA </h2>
                    </a></li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse"><i
                            class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i
                            class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary"
                            data-feather="disc" data-ticon="disc"></i></a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="active"><a class="d-flex align-items-center" href="homecliente.php"><i
                            data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">PÁGINA
                            INICIAL</span></a></li>

                <li class=" nav-item"><a href="saircliente.php"><i class="text-danger" data-feather='log-out'></i><span class="menu-title" data-i18n="Raise Support">SAIR</span></a>



            </ul>
            </li>
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->


    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper container-xxl p-0">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <!-- Dashboard Analytics Start -->
                <section id="dashboard-analytics">
                    <div class="row">
                        <div class="col-sm-12">
                        </div>
                    </div>
                </section>
                <!-- Dashboard Analytics end -->
                <?php
                if (isset($_GET["page"])) {
                    $page = $_GET["page"];
                    if ($page and file_exists("pages/" . $page . ".php")) {
                        include("pages/" . $page . ".php");
                    } else {
                        include("./pages/inicialcliente.php");
                    }
                } else {
                    include("./pages/inicialcliente.php");
                }
                ?>
            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
        <center>
            <p class="clearfix blue-grey lighten-2 mb-0">
                <span class="center">
                    &copy;
                    <script>
                        document.write(new Date().getFullYear())
                    </script>
                    <a class="text-bold-800 grey darken-2" href="https://coutyssh.com.br" target="_blank">EMPRESA 🚀</a>
                </span>
                </span>

            </p>
        </center>
    </footer>
    <!-- END: Footer-->
    <script src="../app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->
    <!-- BEGIN: Page Vendor JS-->
    <script src="../app-assets/vendors/js/charts/apexcharts.min.js"></script>
    <script src="../app-assets/vendors/js/extensions/moment.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/jszip.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/dataTables.rowGroup.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/dataTables.bootstrap5.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js"></script>
    <script src="../app-assets/vendors/js/tables/datatable/responsive.bootstrap5.js"></script>
    <script src="../app-assets/js/scripts/tables/table-datatables-basic.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="../app-assets/js/core/app-menu.js"></script>
    <script src="../app-assets/js/core/app.js"></script>


    <!-- END: Theme JS-->

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function () {
            var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/5bc3fe7c61d0b77092513c66/1gc8344lc';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->

    <!-- BEGIN: Page JS-->
    <script src="../app-assets/js/scripts/pages/dashboard-analytics.js"></script>
    <script src="../app-assets/js/scripts/pages/app-invoice-list.js"></script>
    <script src="../app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <script src="../app-assets/js/scripts/forms/form-select2.js"></script>

    <script>
        $(window).on('load', function () {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        });

        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "lengthMenu": "_MENU_ Registros por página",
                    "zeroRecords": "Nada encontrado",
                    "info": "Página _PAGE_ de _PAGES_",
                    "infoEmpty": "Não há registros",
                    "infoFiltered": "(filtrando em _MAX_ registros)",
                    "loadingRecords": "Aguarde...",
                    "processing": "Processando...",
                    "search": "Pesquisar:",
                    "zeroRecords": "Nenhum registro encontrado",
                    "paginate": {
                        "first": "Primeiro",
                        "last": "último",
                        "next": "Próximo",
                        "previous": "Anterior"
                    }
                },
                "scrollX": true,
                order: [
                    [3, 'desc'],
                    [0, 'asc']
                ]
            });
        });
    </script>
    <!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>